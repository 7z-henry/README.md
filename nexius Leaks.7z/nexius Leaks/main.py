from terminut import log
import requests
import toml
from datetime import datetime


with open("./data/config.toml") as f:
    config = toml.load(f)

with open(config["artist_file"], "r") as artist_file:
    artists = artist_file.readlines()

timestamp = int(datetime.now().timestamp())

if __name__ == "__main__":
    log.info("Nexius Started")
    log.debug(f"Current Timestamp: {timestamp}")
    log.debug(f"Searching for {len(artists)} artists...")
